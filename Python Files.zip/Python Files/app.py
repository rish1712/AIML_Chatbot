# A very simple Flask Hello World app for you to get started with...

from flask import Flask,request,jsonify
from flask_sqlalchemy import SQLAlchemy
import urllib.parse
#from startup.xml import *

import aiml
import os
import json
print('hello')
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']="sqlite:///users_database.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False

kernel=aiml.Kernel()
kernel.learn("startup.xml")
kernel.respond("load aiml b")
print(kernel.respond('hello'))
if os.path.isfile("bot_brain.brn"):
    kernel.bootstrap(brainFile="bot_brain.brn")

else:
    kernel.bootstrap(learnFiles="startup.xml",commands="LOAD AIML B")
    kernel.saveBrain("bot_brain.brn")


@app.route('/')
def hello_world():
    print("hello world")
    data={"name":"'Hello from Flask!'"}
    return json.dumps(data)

db=SQLAlchemy(app)
class user_database(db.Model):
    __tablename__='users'
    sno = db.Column(db.Integer, primary_key=True)
    user_id=db.Column(db.String(200),nullable=False)
    name=db.Column(db.String(200),nullable=False)
    phone_no=db.Column(db.String(10),nullable=False)
    alt_phone_no=db.Column(db.String(10),nullable=False)
    email=db.Column(db.String(100),nullable=False)
    adress=db.Column(db.String(100),nullable=False)
    #blood_relation=db.Column(db.String(100),nullable=False)
    family_members=db.Column(db.String(100),nullable=False)
    prev=db.Column(db.String(100000),nullable=False)

db.create_all()
@app.route('/hi')
def dimmag():
    return kernel.respond('hello')
@app.route('/posts',methods=['GET','POST'])
def post_requets():
    print("in post method")
    if request.method=='POST':
        json=request.get_json()

        if json['name'][0:7]=='newuser':
            details=json['name'].split(",")
            user=user_database(user_id=details[1],name=details[2],phone_no=details[3],alt_phone_no=details[4],email=details[5],adress=details[6],family_members=details[7],prev=" ")
            db.session.add(user)
            db.session.commit()
            return jsonify({'name':'New User with user id '+details[1]+' has been created'})

        temp=json['name'].split('\n')
        query=temp[1]
        user_id_temp=temp[0]
        #return jsonify({'name':'hi there '})
        #return jsonify({'name':query})
        if query.lstrip()=="yes":
            #return jsonify({'name':query})
            my_user=user_database.query.filter_by(user_id=user_id_temp).first()
            address=my_user.adress
            temp_string=urllib.parse.quote(address)
            return jsonify({'name':"https://www.google.com/maps/search/?api=1&query="+temp_string})


        if query.lstrip()=='old user':
            my_user=user_database.query.filter_by(user_id=user_id_temp).first()
            return jsonify({'name':my_user.prev})
        response=kernel.respond(query.lstrip())
        if response[-9:-1]=='DATABASE':
            number=int(response[-1])
            if number==1:
                my_user=user_database.query.filter_by(user_id=user_id_temp).first()
                name=my_user.name
                response=response.replace("DATABASE"+str(number),name+' with a user_id '+user_id_temp+' as stored in my databses.')
                my_user.prev+=query+'\n'+response+'\n'
                db.session.commit()
                #prev_msgs=
                return jsonify({'name':response})
            if number==2:
                my_user=user_database.query.filter_by(user_id=user_id_temp).first()
                phone=my_user.phone_no
                response=response.replace("DATABASE"+str(number),phone+'.')
                alt_phone_no=my_user.alt_phone_no
                response+="\tIn case you need an additonal phone number here it is "+alt_phone_no
                my_user.prev+=query+'\n'+response+'\n'
                db.session.commit()

                return jsonify({'name':response})

            if number==3:
                my_user=user_database.query.filter_by(user_id=user_id_temp).first()
                email=my_user.email
                response=response.replace("DATABASE"+str(number),' as follows: '+email+'.')
                my_user.prev+=query+'\n'+response+'\n'
                db.session.commit()

                return jsonify({'name':response})

            if number==4:
                my_user=user_database.query.filter_by(user_id=user_id_temp).first()
                address=my_user.adress
                response=response.replace("DATABASE"+str(number),address+'\tIf you want then please write yes so that i can open google maps to your location.')
                my_user.prev+=query+'\n'+response+'\n'
                db.session.commit()

                return jsonify({'name':response})

            if number==5:
                my_user=user_database.query.filter_by(user_id=user_id_temp).first()
                blood_relations=my_user.family_members
                response=response.replace("DATABASE"+str(number),': -'+blood_relations+'.')
                my_user.prev+=query+'\n'+response+'\n'
                db.session.commit()

                return jsonify({'name':response})

        my_user=user_database.query.filter_by(user_id=user_id_temp).first()
        my_user.prev+=query+'\n'+response+'\n'
        db.session.commit()

        return jsonify({'name':response})

    my_user=user_database.query.filter_by(user_id=user_id_temp).first()
    my_user.prev+=query+'\n'+response+'\n'
    db.session.commit()

    return jsonify({'name':response})










